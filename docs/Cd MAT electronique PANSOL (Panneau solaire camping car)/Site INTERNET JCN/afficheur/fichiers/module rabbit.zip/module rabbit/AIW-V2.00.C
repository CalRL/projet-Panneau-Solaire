/***************************************************************
**********         DEFINITIONS                         *********
***************************************************************/

/* configuration IP */

#define IFCONFIG_ETH0 \
	IFS_IPADDR, aton("10.10.10.10"), \
	IFS_NETMASK, aton("255.0.0.0"), \
	IFS_ROUTER_SET, aton("10.0.0.2"), \
	IFS_NAMESERVER_SET, aton("10.0.0.2"), \
	IFS_UP

/* configuration des pages dynamiques */

#define FORM_ERROR_BUF 2048
#define SSPEC_MAXSPEC 50

/* configuration pour liaison s�rie */

#define BINBUFSIZE 127
#define BOUTBUFSIZE 127

#define STX 0x02
#define GS 0x1D
#define ETX 0x03
#define SOH 0x01
#define EOT 0x04

/* d�finitions des es led et switch */

#define DS1 6		//led, port G bit 6
#define DS2 7		//led, port G bit 7
#define S2  1		//switch, port G bit 1
#define S3  0		//switch, port G bit 0

/***************************************************************
**********         LIBRAIRIES & FICHIERS WEB           *********
***************************************************************/

/* librairies & gestion m�moire */

#memmap xmem
#use "dcrtcp.lib"
#use "http.lib"

/* ximport permet d'importer des fichiers */

#ximport "d:\rabbit\aiw/index.htm"     index_html
#ximport "d:\rabbit\aiw/nav.htm"       nav_html
#ximport "d:\rabbit\aiw/main.htm"      main_html
#ximport "d:\rabbit\aiw/ipstat.shtml"  ipstat_shtml
#ximport "d:\rabbit\aiw/fond1.gif"     fond1_gif
#ximport "d:\rabbit\aiw/logo.gif"      logo_gif
#ximport "d:\rabbit\aiw/puce1.gif"     puce1_gif

/* pr�cise le type de fichiers � g�rer par le serveur */
/* la valeur par d�faut '/' doit �tre plac�e en premier */

const HttpType http_types[] =
{
   { ".shtml", "text/html", shtml_handler}, // ssi
   { ".htm", "text/html", NULL},
   { ".cgi", "", NULL},                     // cgi
   { ".gif", "image/gif", NULL},
   { "", "text/plain", NULL},           // generic text
};

/***************************************************************
**********          VARIABLES POUR LES MESSAGES        *********
***************************************************************/

int mes_n;

char mes_text[41];
char mes_clig[41];
char mes_defil[30];
char action_mes[30];
char num_e[3]; 			//message en cours
char num_m[3];

/***************************************************************
**********      VARIABLES POUR LES PARAMETRES IP       *********
***************************************************************/

int first;
char ip_ad[20];
char ip_mask[20];
char ip_pas[30];
char ip_dns[30];
char ip_name[30];
char action_ip[30];

/***************************************************************
**********      FICHIERS POUR PAGES WEB                *********
***************************************************************/

/* http_flashspec associe les fichiers import�s avec ximport avec leur nom dans le serveur web */

const HttpSpec http_flashspec[] =
{
   { HTTPSPEC_FILE,  "/",              index_html,    NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/index.htm",     index_html,    NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/nav.htm",       nav_html,    	NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/main.htm",      main_html,    	NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/ipstat.shtml",     ipstat_shtml,    NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/fond1.gif",     fond1_gif,   NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/logo.gif",      logo_gif,   NULL, 0, NULL, NULL},
   { HTTPSPEC_FILE,  "/puce1.gif",     puce1_gif,   NULL, 0, NULL, NULL},

   { HTTPSPEC_VARIABLE, "ip_ad", 0, ip_ad, PTR16, "%s", NULL},
   { HTTPSPEC_VARIABLE, "ip_mask", 0, ip_mask, PTR16, "%s", NULL},
   { HTTPSPEC_VARIABLE, "ip_pas", 0, ip_pas, PTR16, "%s", NULL},
   { HTTPSPEC_VARIABLE, "ip_dns", 0, ip_dns, PTR16, "%s", NULL},
};

/***************************************************************
**********      DEFINITION DES FONCTIONS               *********
***************************************************************/

void init_es(void);
void init_res(void);
void init_mes(void);
void gest_message(void);
void store_mes(void);
void choix_mes(void);
void effac_mes(void);
void test_mes(void);
void num_mes(void);
void cont_mesn(int n);
void gest_ip(void);
void refresh_ip(void);
void save_ip(void);
void restor_ip(void);
void affi_ip(void);
int launched(HttpState* state);
int delays(int s);

/***************************************************************
**********      PROGRAMME PRINCIPAL                    *********
***************************************************************/

main()
{

/* PARAMETRES DE LA PAGE DES MESSAGES */

	// D�clare le tableau myform1 qui re�oit les variables
	FormVar myform1[15];
	int var1;
	int form1;

	// tableau des choix pour le d�filement
	static const char* const defil_options[] = {
    	"Message fixe",
    	"Message defilant",
    };

   // tableau des choix pour action des messages
	static const char* const action_options[] = {
		"",
    	"Tester un message",
    	"Enregistrer un message",
    	"Effacer un message",
    	"Afficher un message",
    	"Valider un message",
    };

/* PARAMETRES DE LA PAGE DES PARAMETRES RESEAU */

	// D�clare le tableau myform2 qui re�oit les variables
	FormVar myform2[15];
	int var2;
	int form2;
	int function;
   int user;

   // tableau des choix pour modification IP
	static const char* const ip_options[] = {
    	"",
    	"Modifier param�tres",
    	"Initialiser param�tres",
    };

	// cr�ation de l'utilisateur
	user = sauth_adduser("user", "pass", SERVER_HTTP);

/* DEMARRAGE DU PROGRAMME PRINCIPAL */

 	init_mes();
	init_res();
   init_es();

/* CONSTRUCTION PAGE DYNAMIQUE DES MESSAGES */

	// Cr�ation de la page (avec tableau de variables)
	form1 = sspec_addform("creer.htm", myform1, 7, SERVER_HTTP);

	// Fixe le titre
	sspec_setformtitle(form1, "Gestion des messages");

	// numero du message en cours
	var1 = sspec_addvariable("num_e", &num_e, PTR16, "%s",  SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Affichage");
	sspec_setfvdesc(form1, var1, "Numero du message en cours");
	sspec_setfvlen(form1, var1, 3);
	sspec_setfvreadonly(form1, var1, 1);

	// num�ro du message
	var1 = sspec_addvariable("mes_n", &mes_n, INT16, "%d", SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Num�ro du message");
	sspec_setfvdesc(form1, var1, "Valeur entre 1 et 510");
	sspec_setfvlen(form1, var1, 5);
	sspec_setfvrange(form1, var1, 1,510);

	// choix de l'action
	var1 = sspec_addvariable("action_mes", action_mes, PTR16, "%s", SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Action");
	sspec_setfvdesc(form1, var1, "Faites votre choix !");
	sspec_setfvlen(form1, var1, 40);
	sspec_setfvoptlist(form1, var1, action_options, 6);
	sspec_setfventrytype(form1, var1, HTML_FORM_PULLDOWN);

	// choix du defilement
	var1 = sspec_addvariable("mes_defil", mes_defil, PTR16, "%s", SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Choix du d�filement");
	sspec_setfvdesc(form1, var1, "Faites votre choix !");
	sspec_setfvlen(form1, var1, 40);
	sspec_setfvoptlist(form1, var1, defil_options, 2);
	sspec_setfventrytype(form1, var1, HTML_FORM_PULLDOWN);

	// choix du message
	var1 = sspec_addvariable("mes_text", &mes_text, PTR16, "%s",  SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Texte du message");
	sspec_setfvdesc(form1, var1, "Limit� � 40 caract�res");
	sspec_setfvlen(form1, var1, 40);

	// choix du masque de clignotement
	var1 = sspec_addvariable("mes_clig", &mes_clig, PTR16, "%s",  SERVER_HTTP);
	var1 = sspec_addfv(form1, var1);
	sspec_setfvname(form1, var1, "Masque de clignotement");
	sspec_setfvdesc(form1, var1, "Limit� � 40 caract�res");
	sspec_setfvlen(form1, var1, 40);

/* CONSTRUCTION PAGE DYNAMIQUE PARAMETRAGE RESEAU */

	// Cr�ation de la page (avec tableau de variables)
	form2 = sspec_addform("newip.htm", myform2, 8, SERVER_HTTP);

	// Fixe le titre
	sspec_setformtitle(form2, "Param�trage IP");
	function = sspec_addfunction("launched", launched, SERVER_HTTP);
	sspec_setformepilog(form2, function);
	sspec_setuser(form2, user);
	sspec_setrealm(form2, "Admin");

	// masque
	var2 = sspec_addvariable("ip_mask", &ip_mask, PTR16, "%s",  SERVER_HTTP);
	var2 = sspec_addfv(form2, var2);
	sspec_setfvname(form2, var2, "Masque de sous-reseau");
	sspec_setfvdesc(form2, var2, "de la forme : xxx.xxx.xxx.xxx");
	sspec_setfvlen(form2, var2, 20);

	// adresse ip
	var2 = sspec_addvariable("ip_ad", &ip_ad, PTR16, "%s",  SERVER_HTTP);
	var2 = sspec_addfv(form2, var2);
	sspec_setfvname(form2, var2, "Adresse IP");
	sspec_setfvdesc(form2, var2, "de la forme : xxx.xxx.xxx.xxx");
	sspec_setfvlen(form2, var2, 20);

	// adresse dns
	var2 = sspec_addvariable("ip_dns", &ip_dns, PTR16, "%s",  SERVER_HTTP);
	var2 = sspec_addfv(form2, var2);
	sspec_setfvname(form2, var2, "Adresse DNS");
	sspec_setfvdesc(form2, var2, "de la forme : xxx.xxx.xxx.xxx");
	sspec_setfvlen(form2, var2, 20);

	// adresse passerelle
	var2 = sspec_addvariable("ip_pas", &ip_pas, PTR16, "%s",  SERVER_HTTP);
	var2 = sspec_addfv(form2, var2);
	sspec_setfvname(form2, var2, "Passerelle IP");
	sspec_setfvdesc(form2, var2, "de la forme : xxx.xxx.xxx.xxx");
	sspec_setfvlen(form2, var2, 20);

	// choix
	var2 = sspec_addvariable("action_ip", action_ip, PTR16, "%s", SERVER_HTTP);
	var2 = sspec_addfv(form2, var2);
	sspec_setfvname(form2, var2, "Action");
	sspec_setfvdesc(form2, var2, "Faites votre choix !");
	sspec_setfvlen(form2, var2, 40);
	sspec_setfvoptlist(form2, var2, ip_options, 3);
	sspec_setfventrytype(form2, var2, HTML_FORM_PULLDOWN);

/* TEMPORISATION ATTENTE INIT CARTE AFFICHEUR */

	delays(40);
	affi_ip();   

/* LANCEMENT DU SERVEUR ET DU RESEAU */

   sock_init();
   http_init();
   tcp_reserveport(80);

/* BOUCLE D'ATTENTE DES TRAVAUX */

   while (1)
   {
		refresh_ip();
		gest_message();
		gest_ip();
		http_handler();
   }
}

/***************************************************************
**********      FONCTIONS : GESTION DES MESSAGES       *********
***************************************************************/

void gest_message(void)
{
		if (!strcmp(action_mes,"Effacer un message")){
			effac_mes();
			num_mes();
			strcpy(action_mes,"");
			}

		if (!strcmp(action_mes,"Enregistrer un message")){
		   store_mes();
		   num_mes();
			strcpy(action_mes,"");
			}

		if (!strcmp(action_mes,"Tester un message")){
			test_mes();
			num_mes();
			strcpy(action_mes,"");
			}

		if (!strcmp(action_mes,"Afficher un message")){
			cont_mesn(mes_n);
			num_mes();
   		strcpy(action_mes,"");
			}

		if (!strcmp(action_mes,"Valider un message")){
			choix_mes();
			cont_mesn(mes_n);
			num_mes();
   		strcpy(action_mes,"");
			}
}
/***************************************************************
**********      FONCTIONS : GESTION IP                 *********
***************************************************************/

void gest_ip(void)
{
	char scratch[40];
	longword temp;


		if (!strcmp(action_ip,"")){
			ifconfig(IF_ETH0, IFG_IPADDR, &temp, IFS_END);
			inet_ntoa( ip_ad, temp);
			ifconfig(IF_ETH0, IFG_NETMASK, &temp, IFS_END);
			inet_ntoa( ip_mask, temp);
			ifconfig(IF_ETH0, IFG_ROUTER_DEFAULT, &temp, IFS_END);
			inet_ntoa( ip_pas, temp);
			inet_ntoa( scratch, def_nameservers[0]);
			strcpy(ip_dns,scratch);
			BitWrPortI(PGDR, &PGDRShadow, 1, DS1);
			strcpy(action_ip,"");
			}

		if (!strcmp(action_ip,"Modifier param�tres")){
			ifconfig( IF_ETH0,
				IFS_DOWN,
				IFS_IPADDR, aton(ip_ad),
				IFS_NETMASK, aton(ip_mask),
				IFS_ROUTER_SET, aton(ip_pas),
				IFS_NAMESERVER_SET, aton(ip_dns),
				IFS_UP,
				IFS_END);
			strcpy(action_ip,"");
			save_ip();
			}

		if (!strcmp(action_ip,"Initialiser param�tres")){
			ifconfig( IF_ETH0,
				IFS_DOWN,
				IFS_IPADDR, aton("10.10.10.10"),
				IFS_NETMASK, aton("255.0.0.0"),
				IFS_ROUTER_SET, aton("10.0.0.5"),
				IFS_NAMESERVER_SET, aton("10.0.0.5"),
				IFS_UP,
				IFS_END);
			strcpy(action_ip,"");
			save_ip();
			}
}

/***************************************************************
**********  INITIALISATION DES Entr�es Sorties         *********
***************************************************************/

void init_es(void)
{
// initialisation entr�es sortie : configure Port G
	WrPortI(PGCR, &PGCRShadow, 0x00);						//clear all bits for pclk/2
	WrPortI(PGFR, &PGFRShadow, 0x00);						//clear all bits for normal function
	WrPortI(PGDCR, &PGDCRShadow, PGDCRShadow|0xC0);		//set bits 7,6 drive open drain
	WrPortI(PGDR, &PGDRShadow, PGDCRShadow|0xC0);		//set bit 7,6 output high
	BitWrPortI(PGDCR, &PGDCRShadow, 0, 2);					//clear bit 2 drive output
	BitWrPortI(PGDR, &PGDRShadow, 0, 2);					//clear bit 2 output low
	WrPortI(PGDDR, &PGDDRShadow, 0xC4);						//set bits 7,6,2 to output and
	  																	//clear bits 5,4,3,1,0 to input
}

/***************************************************************
**********    INITIALISATION PAGES PARAMETRES RESEAU   *********
***************************************************************/

void init_res(void)
{
	first = 1;

// initialisation affichage configuration r�seau

	strcpy(ip_ad,"10.10.10.10");
	strcpy(ip_mask,"255.0.0.0");
	strcpy(ip_pas,"10.0.0.2");
	strcpy(ip_dns,"10.0.0.3");
	strcpy(ip_name,"aiw.mat.com");
}

/***************************************************************
**********    INITIALISATION DES PAGES WEB             *********
***************************************************************/
// initialisation affichage
void init_mes(void)
{
   mes_n = 1;
   strcpy(num_e,"");
   strcpy(num_m,"");
   strcpy(mes_text,"");
   strcpy(mes_clig,"");
   strcpy(mes_defil,"");
   strcpy(action_mes,"");
}

/***************************************************************
**********      FONCTIONS : STORE_MES                  *********
***************************************************************/
/* memorise un message dans l'afficheur */

void store_mes(void)
{
	char buf_s[40];
	char num_m[3];
	int a,b,i;

	serBopen(9600);
	strcpy(num_m,"");
   itoa(mes_n,num_m);
	serBputc(STX);			//STX
	serBputc(0x30);
	serBputc(0x30);
	serBputc(0x31);
	serBputc(GS);			//GS
	strcpy(buf_s,"");
	sprintf(buf_s,"%3s",num_m);
	if (buf_s[0]==0x20)
		buf_s[0]=0x30;
	if (buf_s[1]==0x20)
		buf_s[1]=0x30;
	serBputs(buf_s);
	serBputc(GS);			//GS
	for (i=0;i <= 39;i++){
		if ((!strcmp(mes_defil,"Message defilant"))&& i==39){
		   serBputc('@');				//@ pour defilement
			}
		else{
			if (i>=strlen(mes_text)&& i<=39){
		   	serBputc(0x20);			//remplissage avec espace
				}
			if (i<strlen(mes_text)&& i<=39){
				a = mes_text[i];
				b = mes_clig[i];
				if ( b==0x63 && i<=strlen(mes_clig))
         		a=a+0x80;
		   	serBputc(a);			//envoie du texte
				}
			}
		}
	serBputc(ETX);			//ETX
	while (serBwrFree() != BOUTBUFSIZE) ;      // attend la fin de la transmission avant de fermer le port
   serBclose();
}

/***************************************************************
**********      FONCTIONS : CHOIX_MES                  *********
***************************************************************/
/* choisit un message dans l'afficheur */

void choix_mes(void)
{
	char buf_s[30];
	char num_m[3];

	serBopen(9600);
	strcpy(num_m,"");
   itoa(mes_n,num_m);
	serBputc(SOH);			//SOH
	serBputc(0x30);
	serBputc(0x30);
	serBputc(0x31);
	serBputc(GS);			//GS
	strcpy(buf_s,"");
	sprintf(buf_s,"%3s",num_m);
	if (buf_s[0]==0x20)
		buf_s[0]=0x30;
	if (buf_s[1]==0x20)
		buf_s[1]=0x30;
	serBputs(buf_s);
	serBputc(GS);			//GS
	while (serBwrFree() != BOUTBUFSIZE) ;      // attend la fin de la transmission avant de fermer le port
   serBclose();
}

/***************************************************************
**********      FONCTIONS : EFFAC_MES                  *********
***************************************************************/
/* efface un message dans l'afficheur */

void effac_mes(void)
{
	strcpy(mes_text,"");
	strcpy(mes_clig,"");
	strcpy(mes_defil,"Message fixe"); 		// 	"Message fixe"
   store_mes();
}

/***************************************************************
**********      FONCTIONS : TEST_MES                  *********
***************************************************************/
/* teste un message sur l'afficheur */

void test_mes(void)
{
	int a;

	a = mes_n;
	mes_n = 511;
	store_mes();
	choix_mes();
	mes_n = a;
}

/***************************************************************
**********      FONCTIONS : NUM_MES                    *********
***************************************************************/
//* demande numero message sur l'afficheur */

void num_mes(void)
{
    int i,j,c;
    char s[50];

	 i=0;
	 j=0;
	 c=0;
	 sprintf(s,"%c%s%c%c%s%s%c",0x05,"001",0x1D,0x1B,"F2","---",0x06);
	 serBopen(9600);
    serBputs(s);
    while (serBwrFree() != BOUTBUFSIZE) ;     // attend la fin de la transmission avant de lire
    while (c != 0x09)
		{
		if ((c = serBgetc()) != -1)
			{
			s[i]=c;
   		i++;
   		}
   	}
   serBclose();
   for(i=5;i<8;i++)									//extraction des donn�es utiles
   	{
   	num_e[j]=s[i];
   	j++;
   	}
}

/***************************************************************
**********      FONCTIONS : CONT_MESN                  *********
***************************************************************/
/* demande message contenu message n l'afficheur */

void cont_mesn(int n)
{
	int i,j,c;
   char s[50];

	i=0;
	j=0;
	c=0;
	itoa(n,num_m);
	sprintf(s,"%c%s%c%c%s%3s%c",0x05,"001",0x1D,0x1B,"F3",num_m,0x06);
	if (s[8]==0x20)
		s[8]=0x30;
	if (s[9]==0x20)
		s[9]=0x30;
	serBopen(9600);
   serBputs(s);
   while (serBwrFree() != BOUTBUFSIZE) ;     // attend la fin de la transmission avant de lire
   while (c != 0x09)
		{
		if ((c = serBgetc()) != -1)
			{
			s[i]=c;
   		i++;
   		}
   	}
   serBclose();

	if (s[44]!='@')
		{
		strcpy(mes_defil,"Message fixe");
		}
	else
		{
		strcpy(mes_defil,"Message defilant");
		}
	for(i=5;i<45;i++)									//extraction des donn�es utiles
   	{
   	if (s[i]>=0x80)
			{
			mes_text[j]=(s[i]-0x80);
			mes_clig[j]='c';
			}
		else
			{
			mes_text[j]=s[i];
			mes_clig[j]=0x20;
			}
   	j++;
   	}
	mes_text[40]=0x00;								//terminateur nul d'une chaine
	mes_clig[40]=0x00;
}

/***************************************************************
**********      FONCTIONS : RAFRAICHISSEMENT IP        *********
***************************************************************/

void refresh_ip(void)

{
 	char b[3];

	if (first==1)
			{
			// eventuellement restauration adresse IP
			readUserBlock(b, 0, 1);
			if (b[0]=='O') {
				restor_ip();
				}
   		first = 0;
			}
	if (!BitRdPortI(PGDR, S2)){
			strcpy(action_ip,"Initialiser param�tres");
			BitWrPortI(PGDR, &PGDRShadow, 0, DS1);
			strcpy(b,"");
			strcat(b, "L");
			writeUserBlock(0, b, 1);
			}
}

/***************************************************************
**********      FONCTIONS : SAVE IP                    *********
***************************************************************/

void save_ip(void)

{
 char buf[100];
 longword temp;

	/*ifconfig(IF_ETH0, IFG_IPADDR, &temp, IFS_END);
	inet_ntoa( ip_ad, temp);
	ifconfig(IF_ETH0, IFG_NETMASK, &temp, IFS_END);
	inet_ntoa( ip_mask, temp);
	ifconfig(IF_ETH0, IFG_ROUTER_DEFAULT, &temp, IFS_END);
	inet_ntoa( ip_pas, temp);
	inet_ntoa( buf, def_nameservers[0]);
	strcpy(ip_dns,buf);*/

	strcpy(buf,"");
	strcat(buf, "O");
	strcat(buf, ip_ad);
	strcat(buf, "O");
	strcat(buf, ip_mask);
	strcat(buf, "O");
	strcat(buf, ip_dns);
	strcat(buf, "O");
	strcat(buf, ip_pas);
	strcat(buf, "O");

	writeUserBlock(0, buf, 100);
}

/***************************************************************
**********      FONCTIONS : RESTOR IP                  *********
***************************************************************/

void restor_ip(void)

{
	int i,j;
	char c;
	char buf[100];

	i=0;
	j=0;
	readUserBlock(buf, 1, 100);

	while((c=buf[i])!='O')
		{
 		ip_ad[j]=c;
 		j++;
 		i++;
 		}
	ip_ad[j]=0x00;
	tcp_config(MY_IP,ip_ad);
	j=0;
	i++;

	while((c=buf[i])!='O')
		{
 		ip_mask[j]=c;
 		j++;
 		i++;
 		}
	ip_mask[j]=0x00;
	tcp_config(NETMASK,ip_mask);
	j=0;
	i++;

	while((c=buf[i])!='O')
		{
 		ip_dns[j]=c;
 		j++;
 		i++;
 		}
	ip_dns[j]=0x00;
	*_last_nameserver = 0;   			/* reset table des serveurs DNS */
	tcp_config(NAMESERVER,ip_dns);
	j=0;
	i++;

	while(((c=buf[i])!='O')||(c==' '))
		{
 		ip_pas[j]=c;
 		j++;
 		i++;
 		}
	ip_pas[j]=0x00;
	router_del_all();
	tcp_config(GATEWAY,ip_pas);
}

/***************************************************************
**********      FONCTIONS : REDIRECTION                *********
***************************************************************/

int launched(HttpState* state)
    {
    cgi_redirectto(state, "http://ip_ad/ipstat.shtml");
    }

/***************************************************************
**********      FONCTION : DELAYS                     *********
***************************************************************/
/* temporisation en s */
int delays(int s)
{
	unsigned long	t0, t1, t2;
	struct tm		rtc;

	tm_rd(&rtc);							// get time in struct tm
	t0 = mktime(&rtc);					// convert struct tm into seconds since 1980
	tm_wr(&rtc);							// set clock
	t1 = mktime(&rtc);
	do {
		t2 = read_rtc();					// read time in seconds since 1980
	} while ( t2 < (t1+s) );
}


/***************************************************************
**********      FONCTION : AFFI_IP                  *********
***************************************************************/
/* affiche l'adresse IP */

void affi_ip(void)
{
	int i,j;
	char buf[25];
	char c;

	i=0;
	j=0;
	readUserBlock(buf, 0, 1);
	if (buf[0]=='O') {
		readUserBlock(buf, 1, 20);
		while((c=buf[i])!='O')
			{
 			ip_ad[j]=c;
 			j++;
 			i++;
 			}
		ip_ad[j]=0x00;
		}
	strcpy(mes_text,"ETHERNET OK V2.00 BY NJC");
   test_mes();
   delays(5);
   strcpy(mes_text,ip_ad);
   test_mes();
   delays(8);
   strcpy(mes_text,"");
   test_mes();
}


